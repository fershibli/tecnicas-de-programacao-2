/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import java.util.List;

/**
 *
 * @author Alunos
 */
public class Usuario implements BaseDAO {
    final String tableName = "USUARIOS";
    private String login;
    private String senha;
    private String idUsuario;
    private String numAgencia;
    private String numConta;

    public Usuario() {
    }

    public Usuario(String login, String senha, String idCli) {
        this.login = login;
        this.senha = senha;
        this.idUsuario = idCli;
    }

    private boolean validaLogin(String login) {
        return login != null && login.trim().length() > 3 && login.length() <= 20;
    }

    private boolean validaSenha(String senha) {
        return senha != null && senha.trim().length() > 5 && senha.length() <= 20;
    }

    private boolean validaIdCli(String idCli) {
        return idCli.trim().length() > 0;
    }
    
    private boolean validaNumAgencia(String numAgencia) {
        return numAgencia != null && numAgencia.trim().length() > 0 && numAgencia.length() <= 5;
    }

    private boolean validaNumConta(String numConta) {
        return numConta != null && numConta.trim().length() > 0 && numConta.length() <= 10;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        if (!validaLogin(login)) {
            throw new IllegalArgumentException("Login inválido. Deve ter mais de 3 caracteres");
        }
        this.login = login;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        if (!validaSenha(senha)) {
            throw new IllegalArgumentException("Senha inválida. Deve ter mais de 5 caracteres");
        }
        this.senha = senha;
    }

    public String getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(String idUsuario) {
        if (!validaIdCli(idUsuario)) {
            throw new IllegalArgumentException("ID do cliente inválido. Deve ser maior que 0.");
        }
        this.idUsuario = idUsuario;
    }
    
    public String getNumAgencia() {
        return numAgencia;
    }

    public void setNumAgencia(String numAgencia) {
        if (!validaNumAgencia(numAgencia)) {
            throw new IllegalArgumentException("Número da agência inválido");
        }
        this.numAgencia = numAgencia;
    }

    public String getNumConta() {
        return numConta;
    }

    public void setNumConta(String numConta) {
        if (!validaNumConta(numConta)) {
            throw new IllegalArgumentException("Número da conta inválido");
        }
        this.numConta = numConta;
    }

    @Override
    public String getTableName() {
        return tableName;
    }

    @Override
    public String dadosSQLValues() {
        return "'"
            + this.getIdUsuario() + "','"
            + this.getSenha() + "', "
            + this.getNumAgencia() + ","
            + this.getNumConta();
    }

    @Override
    public String alteraDadosSQLValues() {
        return "SENHA = '" + this.getSenha() + "', "
            + "NUM_AGE = " + this.getNumAgencia() + ", "
            + "NUM_CC = " + this.getNumConta();
    }

    @Override
    public String termoSQLWhereById() {
        return "ID = '" + this.getIdUsuario()+"'";
    }

    @Override
    public String consultaSQLValues() {
        return "SENHA, NUM_AGE, NUM_CC";
    }

    @Override
    public void importaSQLValues(List<String> dados) {
        if (dados.size() != 3) {
            throw new IllegalArgumentException("Número de dados inválido. Esperado 3 dados.");
        }
        this.setSenha(dados.get(0));
        this.setNumAgencia(dados.get(1));
        this.setNumConta(dados.get(2));
    }
}