/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sistemabancariobackend;
import View.TelaMenu;

/**
 *
 * @author Alunos
 */
public class SistemaBancarioBackend {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        TelaMenu telaInicial = new TelaMenu();
        telaInicial.setVisible(true);
    }
    
}

